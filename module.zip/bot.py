import json
import time

from graia.broadcast import Broadcast
from graia.saya import Saya
from graia.ariadne.app import Ariadne
from graia.ariadne.entry import config
from graia.ariadne.message.chain import MessageChain
from graia.ariadne.message.element import Plain
from graia.ariadne.model import Friend
from graia.saya.builtins.broadcast import BroadcastBehaviour
from graia.scheduler import GraiaScheduler, timers
from graia.scheduler.saya import SchedulerSchema
from graia.saya import Channel
import asyncio
app = Ariadne(
    config(
        verify_key="ServiceVerifyKey",  # 填入 VerifyKey
        account=3520295800,  # 你的机器人的 qq 号
    ),
)


saya = Ariadne.create(Saya)
with saya.module_context():
    saya.require("module.sche")

app.launch_blocking()
